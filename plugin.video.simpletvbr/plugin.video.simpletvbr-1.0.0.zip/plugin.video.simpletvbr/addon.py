import sys
import os
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import xbmcplugin
import threading
import json
from urllib.parse import urlencode, urlparse, parse_qsl, quote_plus, unquote_plus

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
ADDON_URL = f'plugin://{ADDON_ID}'

# O handle é passado como primeiro argumento
if len(sys.argv) > 1:
    handle = int(sys.argv[1])
else:
    handle = -1

class EmbedTVAddon:
    def __init__(self):
        self.playlist_file = os.path.join(ADDON_PROFILE, 'embedtv_playlist_kodi.m3u')
        self.channels_data_file = os.path.join(ADDON_PROFILE, 'channels_data.json')
        
        # Garante que o diretório profile existe
        if not os.path.exists(ADDON_PROFILE):
            os.makedirs(ADDON_PROFILE)
    
    def router(self, **kwargs):
        """Roteamento principal do addon"""
        # Obtém parâmetros da URL do segundo argumento
        if len(sys.argv) > 2:
            params = dict(parse_qsl(sys.argv[2].lstrip('?')))
        else:
            params = {}
        
        mode = params.get('mode', None)
        category = params.get('category', None)
        channel_name = params.get('channel_name', None)
        stream_url = params.get('stream_url', None)
        
        xbmc.log(f"EmbedTV - Modo: {mode}, Categoria: {category}, Canal: {channel_name}", xbmc.LOGDEBUG)
        
        if mode is None:
            # Menu principal
            self.show_main_menu()
        elif mode == 'categories':
            self.show_categories()
        elif mode == 'category_channels':
            self.show_category_channels(category)
        elif mode == 'play_channel':
            self.play_channel(channel_name, stream_url)
        elif mode == 'update_playlist':
            self.update_playlist_dialog()
        elif mode == 'all_channels':
            self.show_all_channels()
        elif mode == 'info':
            self.show_info()
    
    def show_main_menu(self):
        """Menu principal do addon"""
        xbmcplugin.setPluginCategory(handle, ADDON_NAME)
        xbmcplugin.setContent(handle, 'videos')
        
        # Categorias
        list_item = xbmcgui.ListItem(label='Categorias')
        url = f'{ADDON_URL}?mode=categories'
        list_item.setArt({
            'icon': 'DefaultGenre.png',
            'fanart': os.path.join(ADDON_PATH, 'resources', 'fanart.jpg')
        })
        list_item.setInfo('video', {'title': 'Categorias', 'plot': 'Navegar por categorias de canais'})
        xbmcplugin.addDirectoryItem(handle, url, list_item, True)
        
        # Todos os Canais
        list_item = xbmcgui.ListItem(label='Todos os Canais')
        url = f'{ADDON_URL}?mode=all_channels'
        list_item.setArt({
            'icon': 'DefaultTVShows.png',
            'fanart': os.path.join(ADDON_PATH, 'resources', 'fanart.jpg')
        })
        list_item.setInfo('video', {'title': 'Todos os Canais', 'plot': 'Ver todos os canais disponíveis'})
        xbmcplugin.addDirectoryItem(handle, url, list_item, True)
        
        # Atualizar Lista
        list_item = xbmcgui.ListItem(label='Atualizar Lista')
        url = f'{ADDON_URL}?mode=update_playlist'
        list_item.setArt({
            'icon': 'DefaultAddonUpdate.png',
            'fanart': os.path.join(ADDON_PATH, 'resources', 'fanart.jpg')
        })
        list_item.setInfo('video', {'title': 'Atualizar Lista', 'plot': 'Atualizar lista de canais'})
        xbmcplugin.addDirectoryItem(handle, url, list_item, False)
        
        # Informações
        list_item = xbmcgui.ListItem(label='Informações')
        url = f'{ADDON_URL}?mode=info'
        list_item.setArt({
            'icon': 'DefaultAddonInfo.png',
            'fanart': os.path.join(ADDON_PATH, 'resources', 'fanart.jpg')
        })
        list_item.setInfo('video', {'title': 'Informações', 'plot': 'Informações do addon'})
        xbmcplugin.addDirectoryItem(handle, url, list_item, False)
        
        xbmcplugin.endOfDirectory(handle)
    
    def show_categories(self):
        """Exibe lista de categorias"""
        xbmcplugin.setPluginCategory(handle, 'Categorias')
        xbmcplugin.setContent(handle, 'videos')
        
        channels_data = self.load_channels_data()
        if not channels_data:
            xbmcgui.Dialog().ok(ADDON_NAME, 'Nenhum dado de canal encontrado. Atualize a lista primeiro.')
            return
        
        categories = {}
        for channel in channels_data:
            if channel.get('m3u8_url'):  # Só conta canais válidos
                category = channel.get('category', 'Variedades')
                if category not in categories:
                    categories[category] = 0
                categories[category] += 1
        
        if not categories:
            xbmcgui.Dialog().ok(ADDON_NAME, 'Nenhum canal válido encontrado. Atualize a lista.')
            return
        
        for category, count in sorted(categories.items()):
            list_item = xbmcgui.ListItem(label=f'{category} [{count}]')
            url = f'{ADDON_URL}?mode=category_channels&category={quote_plus(category)}'
            list_item.setArt({
                'icon': 'DefaultGenre.png',
                'fanart': os.path.join(ADDON_PATH, 'resources', 'fanart.jpg')
            })
            list_item.setInfo('video', {
                'title': category,
                'plot': f'{count} canais disponíveis na categoria {category}'
            })
            xbmcplugin.addDirectoryItem(handle, url, list_item, True)
        
        xbmcplugin.endOfDirectory(handle)
    
    def show_category_channels(self, category):
        """Exibe canais de uma categoria específica"""
        if not category:
            return
            
        category = unquote_plus(category)
        xbmcplugin.setPluginCategory(handle, f'Categoria: {category}')
        xbmcplugin.setContent(handle, 'videos')
        
        channels_data = self.load_channels_data()
        if not channels_data:
            return
        
        category_channels = [ch for ch in channels_data if ch.get('category') == category and ch.get('m3u8_url')]
        
        if not category_channels:
            xbmcgui.Dialog().ok(ADDON_NAME, f'Nenhum canal válido encontrado na categoria {category}.')
            return
        
        for channel in category_channels:
            list_item = xbmcgui.ListItem(label=channel['name'])
            url = f'{ADDON_URL}?mode=play_channel&channel_name={quote_plus(channel["name"])}&stream_url={quote_plus(channel["m3u8_url"])}'
            
            # Define a arte (logo do canal)
            art = {
                'icon': 'DefaultVideo.png',
                'fanart': os.path.join(ADDON_PATH, 'resources', 'fanart.jpg')
            }
            if channel.get('image'):
                art['thumb'] = channel['image']
                art['icon'] = channel['image']
            
            list_item.setArt(art)
            # list_item.setInfo('video', {
            #     'title': channel['name'],
            #     'genre': channel.get('category', 'Variedades'),
            #     'plot': f"Canal: {channel['name']}\nCategoria: {channel.get('category', 'Variedades')}\nURL: {channel['m3u8_url']}"
            # })
            list_item.setInfo('video', {
                'title': channel['name'],
                'genre': channel.get('category', 'Variedades'),
                'plot': f"Canal: {channel['name']}\nCategoria: {channel.get('category', 'Variedades')}\n"
            })            
            list_item.setProperty('IsPlayable', 'true')
            list_item.setContentLookup(False)
            
            xbmcplugin.addDirectoryItem(handle, url, list_item, False)
        
        xbmcplugin.endOfDirectory(handle)
    
    def show_all_channels(self):
        """Exibe todos os canais disponíveis"""
        xbmcplugin.setPluginCategory(handle, 'Todos os Canais')
        xbmcplugin.setContent(handle, 'videos')
        
        channels_data = self.load_channels_data()
        if not channels_data:
            xbmcgui.Dialog().ok(ADDON_NAME, 'Nenhum dado de canal encontrado. Atualize a lista primeiro.')
            return
        
        valid_channels = [ch for ch in channels_data if ch.get('m3u8_url')]
        
        if not valid_channels:
            xbmcgui.Dialog().ok(ADDON_NAME, 'Nenhum canal válido encontrado. Atualize a lista.')
            return
        
        for channel in valid_channels:
            list_item = xbmcgui.ListItem(label=channel['name'])
            url = f'{ADDON_URL}?mode=play_channel&channel_name={quote_plus(channel["name"])}&stream_url={quote_plus(channel["m3u8_url"])}'
            
            # Define a arte (logo do canal)
            art = {
                'icon': 'DefaultVideo.png',
                'fanart': os.path.join(ADDON_PATH, 'resources', 'fanart.jpg')
            }
            if channel.get('image'):
                art['thumb'] = channel['image']
                art['icon'] = channel['image']
            
            list_item.setArt(art)
            list_item.setInfo('video', {
                'title': channel['name'],
                'genre': channel.get('category', 'Variedades'),
                'plot': f"Canal: {channel['name']}\nCategoria: {channel.get('category', 'Variedades')}"
            })
            list_item.setProperty('IsPlayable', 'true')
            list_item.setContentLookup(False)
            
            xbmcplugin.addDirectoryItem(handle, url, list_item, False)
        
        xbmcplugin.endOfDirectory(handle)
    
    def play_channel(self, channel_name, stream_url):
        """Reproduz um canal específico"""
        if not channel_name or not stream_url:
            xbmcgui.Dialog().ok(ADDON_NAME, 'Erro: Dados do canal incompletos.')
            return

        channel_name = unquote_plus(channel_name)
        stream_url = unquote_plus(stream_url)
        stream_url = stream_url + '|User-Agent=Mozilla%2F5.0%20%28Windows%20NT%2010.0%3B%20Win64%3B%20x64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F91.0.4472.124%20Safari%2F537.36&Origin=https%3A%2F%2Fwww.embedtv.net&Referer=https%3A%2F%2Fwww.embedtv.net%2F'

        xbmc.log(f"EmbedTV - Reproduzindo: {channel_name} - URL: {stream_url}", xbmc.LOGINFO)


        play_item = xbmcgui.ListItem(path=stream_url)
        play_item.setProperty('IsPlayable', 'true')

        # Define informações do vídeo
        play_item.setInfo('video', {
            'title': channel_name,
            'plot': f'Assistindo: {channel_name}'
        })

        xbmcplugin.setResolvedUrl(handle, True, listitem=play_item)

        # Mostra informações do canal
        xbmcgui.Dialog().notification(ADDON_NAME, f'Iniciando: {channel_name}', xbmcgui.NOTIFICATION_INFO, 3000)
    
    def update_playlist_dialog(self):
        """Atualiza a playlist com diálogo de progresso"""
        if not xbmcgui.Dialog().yesno(ADDON_NAME, 'Deseja atualizar a lista de canais?', 'Não', 'Sim'):
            return
        
        progress_dialog = xbmcgui.DialogProgress()
        progress_dialog.create(ADDON_NAME, 'Iniciando atualização da lista...')
        
        def run_scraper():
            try:
                import sys
                sys.path.append(ADDON_PATH)
                from scraper import main as scraper_main
                
                progress_dialog.update(10, 'Obtendo página principal...')
                scraper_main()
                progress_dialog.update(100, 'Finalizando...')
                return True
                
            except Exception as e:
                xbmc.log(f'Erro ao executar scraper: {str(e)}', xbmc.LOGERROR)
                return False
        
        result = [None]
        def thread_target():
            result[0] = run_scraper()
        
        thread = threading.Thread(target=thread_target)
        thread.start()
        
        # Monitora o progresso
        while thread.is_alive():
            if progress_dialog.iscanceled():
                xbmcgui.Dialog().notification(ADDON_NAME, 'Atualização cancelada', xbmcgui.NOTIFICATION_WARNING)
                return
            xbmc.sleep(500)
        
        thread.join()
        progress_dialog.close()
        
        if result[0]:
            xbmcgui.Dialog().ok(ADDON_NAME, 'Lista atualizada com sucesso!')
            # Atualiza a interface
            xbmc.executebuiltin('Container.Refresh')
        else:
            xbmcgui.Dialog().ok(ADDON_NAME, 'Erro ao atualizar a lista. Verifique o log.')
    
    def load_channels_data(self):
        """Carrega os dados dos canais do arquivo JSON"""
        if not os.path.exists(self.channels_data_file):
            xbmc.log(f"EmbedTV - Arquivo não encontrado: {self.channels_data_file}", xbmc.LOGDEBUG)
            return None
        
        try:
            with open(self.channels_data_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                xbmc.log(f"EmbedTV - Dados carregados: {len(data)} canais", xbmc.LOGDEBUG)
                return data
        except Exception as e:
            xbmc.log(f'Erro ao carregar dados dos canais: {str(e)}', xbmc.LOGERROR)
            return None
    
    def show_info(self):
        """Exibe informações do addon"""
        channels_data = self.load_channels_data()
        valid_channels = len([ch for ch in channels_data if ch.get('m3u8_url')]) if channels_data else 0
        total_channels = len(channels_data) if channels_data else 0
        
        info_lines = [
            f'Nome: {ADDON_NAME}',
            f'Versão: {ADDON_VERSION}',
            f'Canais válidos: {valid_channels}/{total_channels}',
            f'Playlist: {self.playlist_file}',
            f'Última atualização: {self.get_file_mod_time(self.channels_data_file)}'
        ]
        
        if channels_data:
            categories = {}
            for channel in channels_data:
                if channel.get('m3u8_url'):
                    category = channel.get('category', 'Variedades')
                    categories[category] = categories.get(category, 0) + 1
            
            if categories:
                info_lines.append('\nCategorias:')
                for category, count in sorted(categories.items()):
                    info_lines.append(f'  {category}: {count} canais')
            else:
                info_lines.append('\nNenhuma categoria com canais válidos.')
        
        xbmcgui.Dialog().textviewer('Informações do Addon', '\n'.join(info_lines))
    
    def get_file_mod_time(self, filepath):
        """Obtém o tempo de modificação do arquivo"""
        if not os.path.exists(filepath):
            return 'Nunca'
        
        import datetime
        mtime = os.path.getmtime(filepath)
        return datetime.datetime.fromtimestamp(mtime).strftime('%d/%m/%Y %H:%M:%S')

def run():
    addon = EmbedTVAddon()
    addon.router()

if __name__ == '__main__':
    run()