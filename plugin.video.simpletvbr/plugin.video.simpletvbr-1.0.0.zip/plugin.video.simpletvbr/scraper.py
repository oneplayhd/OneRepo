import requests
import re
import json
from bs4 import BeautifulSoup
from urllib.parse import urljoin
import time
import concurrent.futures
import os
import xbmc
import xbmcvfs
import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

class EmbedTVScraper:
    def __init__(self):
        self.base_url = "https://www.embedtv.net"
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        
    def get_main_page(self):
        """Obtém a página principal com todos os canais"""
        try:
            response = self.session.get(self.base_url, timeout=10)
            response.raise_for_status()
            return response.text
        except Exception as e:
            xbmc.log(f"Erro ao acessar a página principal: {e}", xbmc.LOGERROR)
            return None
    
    def extract_channels(self, html_content):
        """Extrai informações dos canais da página HTML"""
        soup = BeautifulSoup(html_content, 'html.parser')
        channels = []
        
        # Tenta encontrar os cards de canal - ajuste o seletor conforme necessário
        channel_cards = soup.find_all('div', class_=lambda x: x and 'channel' in x)
        
        if not channel_cards:
            # Fallback: procura por qualquer elemento que possa conter informações de canal
            channel_cards = soup.find_all(['div', 'li'], class_=True)
        
        for card in channel_cards:
            try:
                # Nome do canal - ajuste os seletores conforme o site
                name_tag = (card.find('h3') or 
                           card.find('h2') or 
                           card.find('h4') or
                           card.find('div', class_=lambda x: x and 'title' in str(x).lower()))
                name = name_tag.text.strip() if name_tag else "Desconhecido"
                
                # Remove caracteres inválidos para o Kodi
                name = re.sub(r'[^\w\s\-\.]', '', name)
                
                # Categoria
                category_tag = card.find('p', class_=lambda x: x and 'category' in str(x).lower())
                category = category_tag.text.strip() if category_tag else "Variedades"
                
                # Imagem/logo
                img_tag = card.find('img')
                if img_tag:
                    if 'data-src' in img_tag.attrs:
                        image_url = img_tag['data-src']
                    elif 'src' in img_tag.attrs:
                        image_url = img_tag['src']
                    else:
                        image_url = ""
                else:
                    image_url = ""
                
                # URL da página do canal
                link_tag = card.find('a')
                if link_tag and 'href' in link_tag.attrs:
                    channel_url = urljoin(self.base_url, link_tag['href'])
                else:
                    channel_url = ''
                    continue
                
                # Filtra canais inválidos
                if name == "Desconhecido" or not 'embed' in channel_url or not name.strip():
                    continue
                
                channels.append({
                    'name': name,
                    'category': category,
                    'image': image_url,
                    'url': channel_url,
                    'm3u8_url': None
                })
                
            except Exception as e:
                xbmc.log(f"Erro ao extrair canal: {e}", xbmc.LOGERROR)
                continue
        
        return channels
    
    def extract_m3u8_from_iframe(self, channel_url):
        """Acessa a página do canal e extrai o link M3U8 do iframe"""
        try:
            response = self.session.get(channel_url, timeout=10)
            response.raise_for_status()
            
            # Procura por padrões M3U8
            patterns = [
                r'source:\s*["\'](https?://[^"\']+\.m3u8[^"\']*)["\']',
                r'var\s+player\s*=\s*new\s+Clappr\.Player\([^}]+source:\s*["\'](https?://[^"\']+\.m3u8[^"\']*)["\']',
                r'player\.load\([^}]+source:\s*["\'](https?://[^"\']+\.m3u8[^"\']*)["\']',
                r'["\']source["\']\s*:\s*["\'](https?://[^"\']+\.m3u8[^"\']*)["\']',
                r'https?://[^\s"\']+\.m3u8[^\s"\']*'
            ]
            
            for pattern in patterns:
                matches = re.findall(pattern, response.text, re.IGNORECASE)
                if matches:
                    valid_urls = [url for url in matches if url.startswith('http') and '.m3u8' in url]
                    if valid_urls:
                        return valid_urls[0]
            
            return None
            
        except Exception as e:
            xbmc.log(f"Erro ao extrair M3U8 de {channel_url}: {e}", xbmc.LOGERROR)
            return None
    
    def process_channel(self, channel):
        """Processa um canal individual para obter o link M3U8"""
        xbmc.log(f"Processando: {channel['name']}", xbmc.LOGINFO)
        m3u8_url = self.extract_m3u8_from_iframe(channel['url'])
        # if m3u8_url:
        #     channel['m3u8_url'] = m3u8_url + '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36&Origin=https://www.embedtv.net&Referer=https://www.embedtv.net/'
        # else:
        channel['m3u8_url'] = m3u8_url
        return channel
    
    def generate_m3u_playlist(self, channels):
        """Gera o arquivo M3U com os canais válidos"""
        output_file = os.path.join(ADDON_PROFILE, 'embedtv_playlist_kodi.m3u')
        valid_channels = [ch for ch in channels if ch['m3u8_url'] is not None]
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write('#EXTM3U\n')
            
            for channel in valid_channels:
                f.write(f'#EXTINF:-1 tvg-id="{channel["name"]}" tvg-name="{channel["name"]}" '
                       f'tvg-logo="{channel["image"]}" group-title="{channel["category"]}",{channel["name"]}\n')
                f.write(f'{channel["m3u8_url"]}\n')
        
        return len(valid_channels)
    
    def save_channels_data(self, channels):
        """Salva os dados dos canais em JSON para uso no addon"""
        output_file = os.path.join(ADDON_PROFILE, 'channels_data.json')
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(channels, f, ensure_ascii=False, indent=2)
    
    def scrape_all_channels(self, max_workers=5):
        """Executa todo o processo de scraping"""
        xbmc.log("Obtendo página principal...", xbmc.LOGINFO)
        html_content = self.get_main_page()
        
        if not html_content:
            xbmc.log("Falha ao obter a página principal", xbmc.LOGERROR)
            return []
        
        xbmc.log("Extraindo informações dos canais...", xbmc.LOGINFO)
        channels = self.extract_channels(html_content)
        xbmc.log(f"Encontrados {len(channels)} canais", xbmc.LOGINFO)
        
        if not channels:
            xbmc.log("Nenhum canal encontrado na página", xbmc.LOGERROR)
            return []
        
        xbmc.log("Extraindo links M3U8...", xbmc.LOGINFO)
        # Processa os canais em paralelo
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            processed_channels = list(executor.map(self.process_channel, channels))
        
        return processed_channels

def main():
    scraper = EmbedTVScraper()
    
    channels = scraper.scrape_all_channels()
    
    if not channels:
        xbmc.log("Nenhum canal foi processado", xbmc.LOGERROR)
        return
    
    # Salva dados completos em JSON
    scraper.save_channels_data(channels)
    
    # Gera playlist M3U
    valid_count = scraper.generate_m3u_playlist(channels)
    
    xbmc.log(f"=== RESULTADO ===", xbmc.LOGINFO)
    xbmc.log(f"Total de canais encontrados: {len(channels)}", xbmc.LOGINFO)
    xbmc.log(f"Canais com M3U8 válido: {valid_count}", xbmc.LOGINFO)

if __name__ == "__main__":
    main()