# scrapy.py
# -*- coding: utf-8 -*-
import base64

# Lista de tuplas (nome de exibição)
APKS_LIST = [
    ("OnePlay Alpha",   "aHR0cHM6Ly9vbmVwbGF5aGQuY29tL2Rvd25sb2FkL09uZVBsYXlBbHBoYS5hcGs="),
    ("OnePlay IboPro",  "aHR0cHM6Ly9vbmVwbGF5aGQuY29tL2Rvd25sb2FkL09uZVBsYXlJYm9Qcm8uYXBr"),
    ("OnePlay Xtream",  "aHR0cHM6Ly9vbmVwbGF5aGQuY29tL2Rvd25sb2FkL09uZVBsYXlYdHJlYW0uYXBr"),
    ("OnePlay CDNP2P",  "aHR0cHM6Ly9vbmVwbGF5aGQuY29tL2Rvd25sb2FkL09uZVBsYXlDRE5ici5hcGs"),
    ("Aptoide TV",      "aHR0cHM6Ly9vbmVwbGF5aGQuY29tL2Rvd25sb2FkL0FwdG9pZFRWLmFwaw=="),
    ("WARP VPN",        "aHR0cHM6Ly9vbmVwbGF5aGQuY29tL2Rvd25sb2FkL1ZQTi5hcGs"),
]

def safe_b64decode(data: str) -> str:
    """Decodifica base64 mesmo se faltar padding"""
    # adiciona "=" até o comprimento ser múltiplo de 4
    missing_padding = len(data) % 4
    if missing_padding:
        data += "=" * (4 - missing_padding)
    return base64.b64decode(data.encode("utf-8")).decode("utf-8")

def listar_apks():
    """
    Retorna uma lista de tuplas (nome, url) a partir de APKS_LIST.
    O 'nome' será exibido no diálogo, e o 'url' (decodificado de Base64)
    será usado para download.
    """
    resultado = []
    for nome, b64 in APKS_LIST:
        url = safe_b64decode(b64)
        resultado.append((nome, url))
    return resultado


if __name__ == "__main__":
    for nome, url in listar_apks():
        print(f"{nome} → {url}")
