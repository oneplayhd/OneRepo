# -*- coding: utf-8 -*-
try:
    from kodi_six import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
except ImportError:
    import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
import os
import six

addon = xbmcaddon.Addon()
addonName = addon.getAddonInfo('name')
homeDir = addon.getAddonInfo('path')
translate = xbmcvfs.translatePath if six.PY3 else xbmc.translatePath
addonIcon = translate(os.path.join(homeDir, 'icon.png'))

## path images
background_image_path = translate(os.path.join(homeDir,'resources','media','background3.png'))
background_image_path_login = translate(os.path.join(homeDir,'resources','media','background.jpg'))
login_button_normal = translate(os.path.join(homeDir,'resources','media','login_unselect.png'))
login_button_hover = translate(os.path.join(homeDir,'resources','media','login_select.png'))
cancel_button_normal = translate(os.path.join(homeDir,'resources','media','sair_unselect.png'))
cancel_button_hover = translate(os.path.join(homeDir,'resources','media','sair_select.png'))
tv_image1 = translate(os.path.join(homeDir,'resources','media','tv.jpg'))
tv_image2 = translate(os.path.join(homeDir,'resources','media','tv2.jpg'))
filmes_image1 = translate(os.path.join(homeDir,'resources','media','filmes.png'))
series_image1 = translate(os.path.join(homeDir,'resources','media','series.png'))
filmes_image2 = translate(os.path.join(homeDir,'resources','media','filmes2.png'))
series_image2 = translate(os.path.join(homeDir,'resources','media','series2.png'))
voltar_normal = translate(os.path.join(homeDir,'resources','media','voltar.png'))
voltar_hover = translate(os.path.join(homeDir,'resources','media','voltar2.png'))
deslogar_normal = translate(os.path.join(homeDir,'resources','media','deslogar.png'))
deslogar_hover = translate(os.path.join(homeDir,'resources','media','deslogar2.png'))
anterior_normal = translate(os.path.join(homeDir,'resources','media','pagina_anterior_unselect.png'))
anterior_hover = translate(os.path.join(homeDir,'resources','media','pagina_anterior_select.png'))
proximo_normal = translate(os.path.join(homeDir,'resources','media','proximo_unselect.png'))
proximo_hover = translate(os.path.join(homeDir,'resources','media','proximo_select.png'))
tela_normal = translate(os.path.join(homeDir,'resources','media','inicial_unselect.png'))
tela_hover = translate(os.path.join(homeDir,'resources','media','inicial_select.png'))
speedtest1 = translate(os.path.join(homeDir,'resources','media','speedtest.png'))
speedtest2 = translate(os.path.join(homeDir,'resources','media','speedtest2.png'))
doramas1 = translate(os.path.join(homeDir,'resources','media','doramas.png'))
doramas2 = translate(os.path.join(homeDir,'resources','media','doramas2.png'))
novelas1 = translate(os.path.join(homeDir,'resources','media','novelas.png'))
novelas2 = translate(os.path.join(homeDir,'resources','media','novelas2.png'))
anime1 = translate(os.path.join(homeDir,'resources','media','anime.png'))
anime2 = translate(os.path.join(homeDir,'resources','media','anime2.png'))
adultos1 = translate(os.path.join(homeDir,'resources','media','adultos.png'))
adultos2 = translate(os.path.join(homeDir,'resources','media','adultos2.png'))
