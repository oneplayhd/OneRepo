import xbmcaddon
import os

ADDON_ID = xbmcaddon.Addon().getAddonInfo('id')
PATH = xbmcaddon.Addon().getAddonInfo('path')
ART = os.path.join(PATH, 'resources', 'media')

ADDONTITLE = '[COLORdeepskyblue]K.U.S[/COLOR] Wizard'
BUILDERNAME = 'SGKodi'
EXCLUDES = [ADDON_ID, 'repository.kus.allinone']
BUILDFILE = 'https://bit.ly/4fCzg2x'
UPDATECHECK = 0

ICONBUILDS = os.path.join(ART, 'builds.png')
ICONCLEAN = os.path.join(ART, 'clean.png')
ICONREPO = os.path.join(ART, 'repo.png')
ICONNET = os.path.join(ART, 'network.png')
ICONSAVE = os.path.join(ART, 'save.png')
ICONLOGIN = os.path.join(ART, 'login.png')
ICONLOG = os.path.join(ART, 'log.png')
ICONDEV = os.path.join(ART, 'dev.png')
ICONSETTINGS = os.path.join(ART, 'settings.png')

HIDESPACERS = 'No'
SPACER = '='

COLOR1 = 'deepskyblue'
COLOR2 = 'white'
THEME1 = u'[COLOR {color1}]K.U.S[/COLOR] Wizard'.format(color1=COLOR1, color2=COLOR2)
THEME2 = u'[COLOR {color1}]{{}}[/COLOR]'.format(color1=COLOR1)
THEME3 = u'[COLOR {color1}]{{}}[/COLOR]'.format(color1=COLOR1)
THEME4 = u'Aktuelles Build: [COLOR {color2}]{{}}[/COLOR]'.format(color1=COLOR1, color2=COLOR2)
THEME5 = u'[COLOR {color1}]Aktuelles Theme:[/COLOR] {{}}'.format(color1=COLOR1, color2=COLOR2)

##############################################################
#                                                            #
#  Copyright (C) 2025 SGKodi / Kodi Unlimited Support Group  #
#                                                            #
##############################################################



