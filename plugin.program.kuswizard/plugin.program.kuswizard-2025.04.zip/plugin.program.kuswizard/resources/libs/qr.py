import xbmcgui
import os

from resources.libs.common.config import CONFIG

def generate_code(url, filename):
    import segno

    if not os.path.exists(CONFIG.QRCODES):
        os.makedirs(CONFIG.QRCODES)
    imagefile = os.path.join(CONFIG.QRCODES, '{0}.png'.format(filename))
    generated_qr = segno.make(url)
    generated_qr.save(imagefile, scale=10)
    return imagefile

def create_code():
    from resources.libs.common import tools

    dialog = xbmcgui.Dialog()

    url = tools.get_keyboard('', "{0}: Gib eine URL für den QR-Code ein".format(CONFIG.ADDONTITLE))
    response = tools.open_url(url, check=True)
    
    if not response:
        if not dialog.yesno(CONFIG.ADDONTITLE,"Die von dir eingegebene URL ist entweder ungültig oder funktioniert nicht. Willst du trotzdem den QR-Code erstellen?".format(CONFIG.COLOR2)+'\n'+"[COLORdeepskyblue]{1}[/COLOR]".format(CONFIG.COLOR1, url), yeslabel="[COLORred]JA[/COLOR]", nolabel="[COLORlime]NEIN[/COLOR]"):
            return
    name = tools.get_keyboard('', "{0}: Gib eine Bezeichnung für den QR-Code ein.".format(CONFIG.ADDONTITLE))
    name = "QR_Code_{0}".format(tools.id_generator(6)) if name == "" else name
    image = generate_code(url, name)
    dialog.ok(CONFIG.ADDONTITLE,"Der QR-Code wurde erstellt und befindet sich im Verzeichnis addon_data:".format(CONFIG.COLOR2)+'\n'+"[COLORdeepskyblue]{1}[/COLOR]".format(CONFIG.COLOR1, image.replace(CONFIG.HOME, '')))

##############################################################
#                                                            #
#  Copyright (C) 2025 SGKodi / Kodi Unlimited Support Group  #
#                                                            #
##############################################################	