import xbmc
import xbmcgui

import hashlib
import math
import os
import re
import socket
import sys
import threading
import timeit

import xml.etree.ElementTree as ET
from xml.dom import minidom as DOM

try:
    from urllib.request import urlopen
    from urllib.request import Request
    from urllib.request import HTTPError
    from urllib.request import URLError
    from urllib.parse import urlparse
    from urllib.parse import parse_qs
    from http.client import HTTPConnection
    from http.client import HTTPSConnection
    from queue import Queue
except ImportError:
    from urllib2 import urlopen
    from urllib2 import Request
    from urllib2 import HTTPError
    from urllib2 import URLError
    from urlparse import urlparse
    from urlparse import parse_qs
    from httplib import HTTPConnection
    from httplib import HTTPSConnection
    from Queue import Queue

from resources.libs.common.config import CONFIG
from resources.libs.common import logging
from resources.libs.common import tools

__version__ = '0.3.5'
user_agent = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 SE 2.X MetaSr 1.0'
source = None
shutdown_event = None
scheme = 'http'
socket_socket = socket.socket

def net_info():
    import json
    from resources.libs.common import logging

    infoLabel = ['Network.IPAddress',
                 'Network.MacAddress']
    data = []
    x = 0
    for info in infoLabel:
        temp = tools.get_info_label(info)
        y = 0
        while temp == "Busy" and y < 10:
            temp = tools.get_info_label(info)
            y += 1
            logging.log("{0} sleep {1}".format(info, str(y)))
            xbmc.sleep(200)
        data.append(temp)
        x += 1
    try:
        url = 'http://extreme-ip-lookup.com/json/'
        req = Request(url)
        req.add_header('User-Agent',
                       'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urlopen(req)
        geo = json.load(response)
    except:
        url = 'http://ip-api.com/json'
        req = Request(url)
        req.add_header('User-Agent',
                       'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urlopen(req)
        geo = json.load(response)
    mac = data[1]
    inter_ip = data[0]
    ip = geo['query']
    isp = geo['org']
    city = geo['city']
    country = geo['country']
    state = geo['region']
    return mac, inter_ip, ip, city, state, country, isp

def main():
    try:
        speedtest()
    except KeyboardInterrupt:
        logging.log('\nCancelling...', level=xbmc.LOGDEBUG)
        dp = xbmcgui.DialogProgress()
        dp.close()
        sys.exit()

if __name__ == '__main__':
    main()

##############################################################
#                                                            #
#  Copyright (C) 2025 SGKodi / Kodi Unlimited Support Group  #
#                                                            #
##############################################################	