import xbmc
import os
from resources.libs.common import directory
from resources.libs.common import logging
from resources.libs.common import tools
from resources.libs.common.config import CONFIG

class MaintenanceMenu:

    def clean_menu(self):
        from resources.libs import clear
        from resources.libs.common import tools

        on = '[COLORlime]AN[/COLOR]'
        off = '[COLORred]AUS[/COLOR]'

        autoclean = 'true' if CONFIG.AUTOCLEANUP == 'true' else 'false'
        cache = 'true' if CONFIG.AUTOCACHE == 'true' else 'false'
        packages = 'true' if CONFIG.AUTOPACKAGES == 'true' else 'false'
        thumbs = 'true' if CONFIG.AUTOTHUMBS == 'true' else 'false'
        includevid = 'true' if CONFIG.INCLUDEVIDEO == 'true' else 'false'
        includeall = 'true' if CONFIG.INCLUDEALL == 'true' else 'false'

        sizepack = tools.get_size(CONFIG.PACKAGES)
        sizethumb = tools.get_size(CONFIG.THUMBNAILS)
        archive = tools.get_size(CONFIG.ARCHIVE_CACHE)
        sizecache = (clear.get_cache_size()) - archive
        totalsize = sizepack + sizethumb + sizecache

        directory.add_file('[Clean] komplett: [COLORdeepskyblue]{0}[/COLOR]'.format(tools.convert_size(totalsize)), {'mode': 'fullclean'}, icon=CONFIG.ICONCLEAN)
        directory.add_file('[Clean] Cache: [COLORdeepskyblue]{0}[/COLOR]'.format(tools.convert_size(sizecache)), {'mode': 'clearcache'}, icon=CONFIG.ICONCLEAN)
        directory.add_file('[Clean] Packages: [COLORdeepskyblue]{0}[/COLOR]'.format(tools.convert_size(sizepack)), {'mode': 'clearpackages'}, icon=CONFIG.ICONCLEAN)
        directory.add_file('[Clean] Thumbnails: [COLORdeepskyblue]{0}[/COLOR]'.format(tools.convert_size(sizethumb)), {'mode': 'clearthumb'}, icon=CONFIG.ICONCLEAN)
        if os.path.exists(CONFIG.ARCHIVE_CACHE):
            directory.add_file('[Clean] Archive Cache: [COLORdeepskyblue]{0}[/COLOR]'.format(tools.convert_size(archive)), {'mode': 'cleararchive'}, icon=CONFIG.ICONCLEAN)
        if xbmc.getCondVisibility('System.HasAddon(script.module.urlresolver)') or xbmc.getCondVisibility('System.HasAddon(script.module.resolveurl)'):
            directory.add_file('[Clean] Resolver Cache', {'mode': 'clearfunctioncache'}, icon=CONFIG.ICONCLEAN)			
        directory.add_file('[Clean] alte Thumbnails', {'mode': 'oldThumbs'}, icon=CONFIG.ICONCLEAN)
        directory.add_file('[Clean] Crash Logs', {'mode': 'clearcrash'}, icon=CONFIG.ICONCLEAN)
        directory.add_file('[Clean] Datenbanken', {'mode': 'purgedb'}, icon=CONFIG.ICONCLEAN)
        directory.add_separator(icon=CONFIG.ICONCLEAN)
        directory.add_file('[Clean] automatisch beim Kodistart: {0}'.format(autoclean.replace('true', on).replace('false', off)), {'mode': 'togglesetting', 'name': 'autoclean'}, icon=CONFIG.ICONCLEAN)
        if autoclean == 'true':
            directory.add_file('[Clean] Intervall: [COLORdeepskyblue]{0}[/COLOR]'.format(CONFIG.CLEANFREQ[CONFIG.AUTOFREQ]), {'mode': 'changefreq'}, icon=CONFIG.ICONCLEAN)
            directory.add_file('[Clean] Cache: {0}'.format(cache.replace('true', on).replace('false', off)), {'mode': 'togglesetting', 'name': 'clearcache'}, icon=CONFIG.ICONCLEAN)
            directory.add_file('[Clean] Packages: {0}'.format(packages.replace('true', on).replace('false', off)), {'mode': 'togglesetting', 'name': 'clearpackages'}, icon=CONFIG.ICONCLEAN)
            directory.add_file('[Clean] alte Thumbnails: {0}'.format(thumbs.replace('true', on).replace('false', off)), {'mode': 'togglesetting', 'name': 'clearthumbs'}, icon=CONFIG.ICONCLEAN)
        directory.add_separator(icon=CONFIG.ICONCLEAN)
        directory.add_file('[Clean] Video Cache mit normalem Cache: {0}'.format(includevid.replace('true', on).replace('false', off)), {'mode': 'togglecache', 'name': 'includevideo'}, icon=CONFIG.ICONCLEAN)

        if includeall == 'true':
            includetmdbhelper = 'true'
        else:
            includetmdbhelper = 'true' if CONFIG.INCLUDETMDBHELPER == 'true' else 'false'

        if includevid == 'true':
            directory.add_file('> Inklusive aller Video Addons: {0}'.format(includeall.replace('true', on).replace('false', off)), {'mode': 'togglecache', 'name': 'includeall'}, icon=CONFIG.ICONCLEAN)
            if xbmc.getCondVisibility('System.HasAddon(plugin.video.themoviedb.helper)'):
                directory.add_file('> Inklusive TMDbHelper: {0}'.format(includetmdbhelper.replace('true', on).replace('false', off)), {'mode': 'togglecache', 'name': 'includetmdbhelper'}, icon=CONFIG.ICONCLEAN)
            directory.add_file('> Alle Video Addons hinzufügen', {'mode': 'togglecache', 'name': 'true'}, icon=CONFIG.ICONCLEAN)
            directory.add_file('> Alle Video Addons ausschließen', {'mode': 'togglecache', 'name': 'false'}, icon=CONFIG.ICONCLEAN)
        directory.add_separator(icon=CONFIG.ICONCLEAN)
        directory.add_file('[Clean] [COLORred]Kodi auf Werkseinstellung zurück setzten[/COLOR]', {'mode': 'freshstart'}, icon=CONFIG.ICONCLEAN)		

    def addon_menu(self):
        directory.add_file('Unbekannte Quellen de-/aktivieren', {'mode': 'unknownsources'}, icon=CONFIG.ICONREPO)
        directory.add_separator(icon=CONFIG.ICONREPO)
        directory.add_file('[Check] alle Quellen', {'mode': 'checksources'}, icon=CONFIG.ICONREPO)
        directory.add_file('[Check] alle Repos', {'mode': 'checkrepos'}, icon=CONFIG.ICONREPO)
        directory.add_separator(icon=CONFIG.ICONREPO)		
        directory.add_file('[Update] Einstellungen', {'mode': 'toggleupdates'}, icon=CONFIG.ICONREPO)		
        directory.add_file('[Update] alle Repos', {'mode': 'forceupdate'}, icon=CONFIG.ICONREPO)
        directory.add_file('[Update] alle Addons', {'mode': 'forceupdate', 'action': 'auto'}, icon=CONFIG.ICONREPO)
   
    def logging_menu(self):
        errors = int(logging.error_checking(count=True))
        errorsfound = str(errors) + ' Fehler gefunden' if errors > 0 else 'Keine'
        wizlogsize = ': [COLORred]Keine[/COLOR]' if not os.path.exists(
            CONFIG.WIZLOG) else "[COLORdeepskyblue]{0}[/COLOR]".format(
            tools.convert_size(os.path.getsize(CONFIG.WIZLOG)))
            
        directory.add_file('Debug Logging de-/aktivieren', {'mode': 'enabledebug'}, icon=CONFIG.ICONLOG)
        directory.add_separator(icon=CONFIG.ICONLOG)		
        directory.add_file('[LOG] Fehler anzeigen: [COLORdeepskyblue]{0}[/COLOR]'.format(errorsfound), {'mode': 'viewerrorlog'}, icon=CONFIG.ICONLOG)
        if errors > 0:
            directory.add_file('[LOG] Letzten Fehler anzeigen', {'mode': 'viewerrorlast'}, icon=CONFIG.ICONLOG)
        directory.add_file('[LOG] anzeigen', {'mode': 'viewlog'}, icon=CONFIG.ICONLOG)
        directory.add_file('[LOG] hochladen', {'mode': 'uploadlog'}, icon=CONFIG.ICONLOG)
        directory.add_separator(icon=CONFIG.ICONLOG)
        directory.add_file('[Wizard LOG] anzeigen', {'mode': 'viewwizlog'}, icon=CONFIG.ICONLOG)
        directory.add_file('[Wizard LOG] bereinigen: {0}'.format(wizlogsize), {'mode': 'clearwizlog'}, icon=CONFIG.ICONLOG)

    def backup_menu(self):
        directory.add_dir('[Backup] Einstellungen', {'mode': 'savedata'}, icon=CONFIG.ICONSAVE)
        directory.add_separator(icon=CONFIG.ICONSAVE)		
        directory.add_file('[Backup]: Build', {'mode': 'backup', 'action': 'build'}, icon=CONFIG.ICONSAVE)
        directory.add_file('[Restore]: lokales Build', {'mode': 'restore', 'action': 'build'}, icon=CONFIG.ICONSAVE)
        directory.add_file('[Restore]: externes Build', {'mode': 'restore', 'action': 'build', 'name': 'external'}, icon=CONFIG.ICONSAVE)
        directory.add_separator(icon=CONFIG.ICONSAVE)
        directory.add_file('[Backup] Verzeichnis: [COLORdeepskyblue]{1}[/COLOR]'.format(CONFIG.COLOR2, CONFIG.MYBUILDS), icon=CONFIG.ICONSAVE)		
        directory.add_file('[Clean] [COLORred]Backup Verzeichnis[/COLOR]', {'mode': 'clearbackup'}, icon=CONFIG.ICONSAVE)

##############################################################
#                                                            #
#  Copyright (C) 2025 SGKodi / Kodi Unlimited Support Group  #
#                                                            #
##############################################################		