import os
from resources.libs.common import directory
from resources.libs.common.config import CONFIG

class MainMenu:

    def get_listing(self):
        from resources.libs import check
        from resources.libs.common import logging
        from resources.libs.common import tools

        errors = int(logging.error_checking(count=True))
        errorsfound = str(errors) + ' Error(s) Found' if errors > 0 else 'None Found'

        if len(CONFIG.BUILDNAME) > 0:
            version = check.check_build(CONFIG.BUILDNAME, 'version')
            build = '[COLORdeepskyblue]{0} (v.{1})[/COLOR]'.format(CONFIG.BUILDNAME, CONFIG.BUILDVERSION)
            if version > CONFIG.BUILDVERSION:
                build = '{0} [COLORred][UPDATE v.{1}][/COLOR]'.format(build, version)
            directory.add_dir(build, {'mode': 'viewbuild', 'name': CONFIG.BUILDNAME}, themeit=CONFIG.THEME4)

            from resources.libs.gui.build_menu import BuildMenu

        else:
            directory.add_dir('[COLORdeepskyblue]Keins[/COLOR]', {'mode': 'builds'}, themeit=CONFIG.THEME4)
        directory.add_dir('Build installieren', {'mode': 'builds'}, icon=CONFIG.ICONBUILDS)
        directory.add_dir('Repos / Addons', {'mode': 'maint', 'name': 'addon'}, icon=CONFIG.ICONREPO)
        directory.add_dir('Backup / Restore', {'mode': 'maint', 'name': 'backup'}, icon=CONFIG.ICONSAVE)
        directory.add_dir('Bereinigung', {'mode': 'maint', 'name': 'clean'}, icon=CONFIG.ICONCLEAN)
        directory.add_dir('LOG', {'mode': 'maint', 'name': 'logging'}, icon=CONFIG.ICONLOG)
        directory.add_dir('Netzwerk', {'mode': 'nettools'}, icon=CONFIG.ICONNET)
        if CONFIG.DEVELOPER == 'true':
            directory.add_dir('Developer Menu', {'mode': 'developer'}, icon=CONFIG.ICONDEV)		
        directory.add_file('Einstellungen', {'mode': 'settings', 'name': CONFIG.ADDON_ID}, icon=CONFIG.ICONSETTINGS)

##############################################################
#                                                            #
#  Copyright (C) 2025 SGKodi / Kodi Unlimited Support Group  #
#                                                            #
##############################################################		