import xbmc
import xbmcgui
import os
import time

from xml.etree import ElementTree
from resources.libs.common.config import CONFIG
from resources.libs.common import logging
from resources.libs.common import tools

ORDER = ['waipu_pvr','zattoo_pvr','teleboy_pvr',
         'zattootv','zattoohiq','hdaustria',
         'rtlplus','disney','paramount','crunchyroll',
         'spotify','deezer','tidal',
         'dazn','magenta_sport','wwenetwork',
         'omdb_tmdbhelper','mdblist_tmdbhelper','fanarttv_tmdbhelper','trakt_tmdbhelper',
         'omdb_skinhelper','tmdb_skinhelper','fanarttv_skinhelper','trakt_skinhelper','adb_skinhelper',		 
         'xstream_aniworld','xstream_flimmerstube','xstream_serienstream',
         'xship_aniworld','xship_flimmerstube','xship_serienstream','xship_tmdb','xship_trakt','xship_fanarttv','xship_opensubtitles',
         'trakt',
         'opensubtitles_org','opensubtitles_com',
         'youtube','youtube_music','youtube_musicbox']		 

LOGINID = {
    'waipu_pvr': {
        'name'     : 'Waipu PVR Account',
        'plugin'   : 'pvr.waipu',
        'saved'    : 'waipu_pvr',
        'path'     : os.path.join(CONFIG.ADDONS, 'pvr.waipu'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'pvr.waipu', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'pvr.waipu', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'waipu_pvr'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'pvr.waipu', 'settings.xml'),
        'default'  : 'username',
        'data'     : ['username', 'password'],
        'activate' : ''},
    'zattoo_pvr': {
        'name'     : 'Zattoo PVR Account',
        'plugin'   : 'pvr.zattoo',
        'saved'    : 'zattoo_pvr',
        'path'     : os.path.join(CONFIG.ADDONS, 'pvr.zattoo'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'pvr.zattoo', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'pvr.zattoo', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'zattoo_pvr'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'pvr.zattoo', 'settings.xml'),
        'default'  : 'username',
        'data'     : ['username', 'password'],
        'activate' : ''},
    'teleboy_pvr': {
        'name'     : 'Teleboy PVR Account',
        'plugin'   : 'pvr.teleboy',
        'saved'    : 'teleboy_pvr',
        'path'     : os.path.join(CONFIG.ADDONS, 'pvr.teleboy'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'pvr.teleboy', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'pvr.teleboy', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'teleboy_pvr'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'pvr.teleboy', 'settings.xml'),
        'default'  : 'username',
        'data'     : ['username', 'password'],
        'activate' : ''},

    'zattootv': {
        'name'     : 'ZattooTV Account',
        'plugin'   : 'plugin.video.zattoo_com',
        'saved'    : 'zattootv',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.zattoo_com'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.zattoo_com', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.zattoo_com', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'zattootv'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.zattoo_com', 'settings.xml'),
        'default'  : 'username',
        'data'     : ['username', 'password'],
        'activate' : ''},
    'zattoohiq': {
        'name'     : 'ZattooHiQ Account',
        'plugin'   : 'plugin.video.zattoo_hiq',
        'saved'    : 'zattoohiq',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.zattoo_hiq'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.zattoo_hiq', 'resources/icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.zattoo_hiq', 'resources/fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'zattoohiq'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.zattoo_hiq', 'settings.xml'),
        'default'  : 'username',
        'data'     : ['username', 'password'],
        'activate' : ''},
    'hdaustria': {
        'name'     : 'HD Austria TV Account',
        'plugin'   : 'plugin.video.hdaustria',
        'saved'    : 'hdaustria',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.hdaustria'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.hdaustria', 'resources/icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.hdaustria', 'resources/fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'hdaustria'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.hdaustria', 'settings.xml'),
        'default'  : 'username',
        'data'     : ['username', 'password'],
        'activate' : ''},

    'rtlplus': {
        'name'     : 'RTL+ Account',
        'plugin'   : 'plugin.video.rtlgroup.de',
        'saved'    : 'rtlplus',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.rtlgroup.de'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.rtlgroup.de', 'resources/media/icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.rtlgroup.de', 'resources/media/fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'rtlplus'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.rtlgroup.de', 'settings.xml'),
        'default'  : 'username',
        'data'     : ['username', 'password', 'authtoken'],
        'activate' : ''},
    'disney': {
        'name'     : 'Disney+ Account',
        'plugin'   : 'slyguy.disney.plus',
        'saved'    : 'disney',
        'path'     : os.path.join(CONFIG.ADDONS, 'slyguy.disney.plus'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'slyguy.disney.plus', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'slyguy.disney.plus', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'disney'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'slyguy.disney.plus', 'settings.xml'),
        'default'  : '_userdata',
        'data'     : ['_userdata'],
        'activate' : ''},
    'paramount': {
        'name'     : 'Paramount+ Account',
        'plugin'   : 'slyguy.paramount.plus',
        'saved'    : 'paramount',
        'path'     : os.path.join(CONFIG.ADDONS, 'slyguy.paramount.plus'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'slyguy.paramount.plus', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'slyguy.paramount.plus', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'paramount'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'slyguy.paramount.plus', 'settings.xml'),
        'default'  : '_userdata',
        'data'     : ['_userdata'],
        'activate' : ''},
    'crunchyroll': {
        'name'     : 'Crunchyroll Account',
        'plugin'   : 'plugin.video.crunchyroll',
        'saved'    : 'crunchyroll',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.crunchyroll'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.crunchyroll', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.crunchyroll', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'crunchyroll'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.crunchyroll', 'settings.xml'),
        'default'  : 'crunchyroll_username',
        'data'     : ['crunchyroll_username', 'crunchyroll_password'],
        'activate' : ''},

    'spotify': {
        'name'     : 'Spotify Account',
        'plugin'   : 'plugin.audio.spotify',
        'saved'    : 'spotify',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.audio.spotify'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.audio.spotify', 'resources/icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.audio.spotify', 'resources/fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'spotify'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.audio.spotify', 'settings.xml'),
        'default'  : 'username',
        'data'     : ['username', 'password'],
        'activate' : ''},
    'deezer': {
        'name'     : 'Deezer Account',
        'plugin'   : 'plugin.audio.deezer',
        'saved'    : 'deezer',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.audio.deezer'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.audio.deezer', 'resources/icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.audio.deezer', 'resources/fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'deezer'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.audio.deezer', 'settings.xml'),
        'default'  : 'username',
        'data'     : ['username', 'password'],
        'activate' : ''},
    'tidal': {
        'name'     : 'Tidal Account',
        'plugin'   : 'plugin.audio.tidal2',
        'saved'    : 'tidal',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.audio.tidal2'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.audio.tidal2', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.audio.tidal2', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'tidal'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.audio.tidal2', 'settings.xml'),
        'default'  : 'client_id',
        'data'     : ['client_id', 'client_secret'],
        'activate' : ''},

    'dazn': {
        'name'     : 'DAZN Account',
        'plugin'   : 'plugin.video.dazn',
        'saved'    : 'dazn',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.dazn'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.dazn', 'resources/icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.dazn', 'resources/fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'dazn'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.dazn', 'settings.xml'),
        'default'  : 'email',
        'data'     : ['email', 'password'],
        'activate' : ''},
    'magenta_sport': {
        'name'     : 'Magenta Sport Account',
        'plugin'   : 'plugin.video.magenta-sport',
        'saved'    : 'magenta_sport',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.magenta-sport'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.magenta-sport', 'resources/media/icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.magenta-sport', 'resources/media/fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'magenta_sport'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.magenta-sport', 'settings.xml'),
        'default'  : 'email',
        'data'     : ['email', 'password'],
        'activate' : ''},
    'wwenetwork': {
        'name'     : 'WWE Network Account',
        'plugin'   : 'plugin.video.wwenetwork',
        'saved'    : 'magenta_sport',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.wwenetwork'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.wwenetwork', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.wwenetwork', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'wwenetwork'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.wwenetwork', 'settings.xml'),
        'default'  : 'username',
        'data'     : ['username', 'password'],
        'activate' : ''},

    'omdb_tmdbhelper': {
        'name'     : 'OMDb Api [TMDbHelper]',
        'saved'    : 'omdb_tmdbhelper',
        'plugin'   : 'plugin.video.themoviedb.helper',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.themoviedb.helper'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.themoviedb.helper', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.themoviedb.helper', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'omdb_tmdbhelper'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.themoviedb.helper', 'settings.xml'),
        'default'  : 'omdb_apikey',
        'data'     : ['omdb_apikey'],
        'activate' : ''},
    'mdblist_tmdbhelper': {
        'name'     : 'MDbList Api [TMDbHelper]',
        'saved'    : 'mdblist_tmdbhelper',
        'plugin'   : 'plugin.video.themoviedb.helper',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.themoviedb.helper'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.themoviedb.helper', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.themoviedb.helper', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'mdblist_tmdbhelper'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.themoviedb.helper', 'settings.xml'),
        'default'  : 'mdblist_apikey',
        'data'     : ['mdblist_apikey'],
        'activate' : ''},
    'fanarttv_tmdbhelper': {
        'name'     : 'Fanart.tv Api [TMDbHelper]',
        'saved'    : 'fanarttv_tmdbhelper',
        'plugin'   : 'plugin.video.themoviedb.helper',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.themoviedb.helper'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.themoviedb.helper', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.themoviedb.helper', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'fanarttv_tmdbhelper'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.themoviedb.helper', 'settings.xml'),
        'default'  : 'fanarttv_clientkey',
        'data'     : ['fanarttv_clientkey'],
        'activate' : ''},
    'trakt_tmdbhelper': {
        'name'     : 'TRAKT Token [TMDbHelper]',
        'saved'    : 'trakt_tmdbhelper',
        'plugin'   : 'plugin.video.themoviedb.helper',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.themoviedb.helper'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.themoviedb.helper', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.themoviedb.helper', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'trakt_tmdbhelper'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.themoviedb.helper', 'settings.xml'),
        'default'  : 'trakt_token',
        'data'     : ['trakt_token'],
        'activate' : ''},
		
    'omdb_skinhelper': {
        'name'     : 'OMDb Api [Skin Helper Service]',
        'plugin'   : 'script.module.metadatautils',
        'saved'    : 'omdb_skinhelper',
        'path'     : os.path.join(CONFIG.ADDONS, 'script.module.metadatautils'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'script.skin.helper.service', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'script.skin.helper.service', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'omdb_skinhelper'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'script.module.metadatautils', 'settings.xml'),
        'default'  : 'omdbapi_apikey',
        'data'     : ['omdbapi_apikey'],
        'activate' : ''},
    'tmdb_skinhelper': {
        'name'     : 'TMDb Api [Skin Helper Service]',
        'plugin'   : 'script.module.metadatautils',
        'saved'    : 'tmdb_skinhelper',
        'path'     : os.path.join(CONFIG.ADDONS, 'script.module.metadatautils'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'script.skin.helper.service', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'script.skin.helper.service', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'tmdb_skinhelper'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'script.module.metadatautils', 'settings.xml'),
        'default'  : 'tmdb_apikey',
        'data'     : ['tmdb_apikey'],
        'activate' : ''},
    'fanarttv_skinhelper': {
        'name'     : 'Fanart.tv Api [Skin Helper Service]',
        'plugin'   : 'script.module.metadatautils',
        'saved'    : 'fanarttv_skinhelper',
        'path'     : os.path.join(CONFIG.ADDONS, 'script.module.metadatautils'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'script.skin.helper.service', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'script.skin.helper.service', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'fanarttv_skinhelper'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'script.module.metadatautils', 'settings.xml'),
        'default'  : 'fanarttv_apikey',
        'data'     : ['fanarttv_apikey'],
        'activate' : ''},
    'trakt_skinhelper': {
        'name'     : 'TRAKT Token [Skin Helper Service]',
        'plugin'   : 'script.module.metadatautils',
        'saved'    : 'trakt_skinhelper',
        'path'     : os.path.join(CONFIG.ADDONS, 'script.module.metadatautils'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'script.skin.helper.service', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'script.skin.helper.service', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'trakt_skinhelper'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'script.module.metadatautils', 'settings.xml'),
        'default'  : 'traktapi_apikey',
        'data'     : ['traktapi_apikey'],
        'activate' : ''},
    'adb_skinhelper': {
        'name'     : 'ADb Api [Skin Helper Service]',
        'plugin'   : 'script.module.metadatautils',
        'saved'    : 'adb_skinhelper',
        'path'     : os.path.join(CONFIG.ADDONS, 'script.module.metadatautils'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'script.skin.helper.service', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'script.skin.helper.service', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'adb_skinhelper'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'script.module.metadatautils', 'settings.xml'),
        'default'  : 'adb_apikey',
        'data'     : ['adb_apikey'],
        'activate' : ''},

    'xstream_aniworld': {
        'name'     : 'AniWorld Account [xStream]',
        'saved'    : 'aniworld_xstream',
        'plugin'   : 'plugin.video.xstream',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.xstream'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.xstream', 'resources/art/sites/aniworld.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.xstream', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'aniworld_xstream'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.xstream', 'settings.xml'),
        'default'  : 'aniworld.user',
        'data'     : ['aniworld.user', 'aniworld.pass'],
        'activate' : ''},
    'xstream_flimmerstube': {
        'name'     : 'Flimmerstube Account [xStream]',
        'saved'    : 'flimmerstube_xstream',
        'plugin'   : 'plugin.video.xstream',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.xstream'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.xstream', 'resources/art/sites/flimmerstube.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.xstream', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'flimmerstube_xstream'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.xstream', 'settings.xml'),
        'default'  : 'flimmerstube.user',
        'data'     : ['flimmerstube.user', 'flimmerstube.pass'],
        'activate' : ''},
    'xstream_serienstream': {
        'name'     : 'Serienstream Account [xStream]',
        'saved'    : 'serienstream_xstream',
        'plugin'   : 'plugin.video.xstream',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.xstream'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.xstream', 'resources/art/sites/serienstream.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.xstream', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'serienstream_xstream'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.xstream', 'settings.xml'),
        'default'  : 'serienstream.user',
        'data'     : ['serienstream.user', 'serienstream.pass'],
        'activate' : ''},

    'xship_aniworld': {
        'name'     : 'AniWorld Account [xShip]',
        'saved'    : 'aniworld_xship',
        'plugin'   : 'plugin.video.xship',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.xship'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.xship', 'resources/icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.xship', 'resources/fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'aniworld_xship'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.xship', 'settings.xml'),
        'default'  : 'aniworld.user',
        'data'     : ['aniworld.user', 'aniworld.pass'],
        'activate' : ''},
    'xship_flimmerstube': {
        'name'     : 'Flimmerstube Account [xShip]',
        'saved'    : 'flimmerstube_xship',
        'plugin'   : 'plugin.video.xship',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.xship'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.xship', 'resources/icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.xship', 'resources/fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'flimmerstube_xship'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.xship', 'settings.xml'),
        'default'  : 'flimmerstube.user',
        'data'     : ['flimmerstube.user', 'flimmerstube.pass'],
        'activate' : ''},
    'xship_serienstream': {
        'name'     : 'Serienstream Account [xShip]',
        'saved'    : 'serienstream_xship',
        'plugin'   : 'plugin.video.xship',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.xship'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.xship', 'resources/icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.xship', 'resources/fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'serienstream_xship'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.xship', 'settings.xml'),
        'default'  : 'serienstream.user',
        'data'     : ['serienstream.user', 'serienstream.pass'],
        'activate' : ''},
    'xship_tmdb': {
        'name'     : 'TMDb Api [xShip]',
        'saved'    : 'tmdb_xship',
        'plugin'   : 'plugin.video.xship',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.xship'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.xship', 'resources/icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.xship', 'resources/fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'tmdb_xship'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.xship', 'settings.xml'),
        'default'  : 'api.tmdb',
        'data'     : ['api.tmdb'],
        'activate' : ''},
    'xship_trakt': {
        'name'     : 'TRAKT Token [xShip]',
        'saved'    : 'trakt_xship',
        'plugin'   : 'plugin.video.xship',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.xship'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.xship', 'resources/icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.xship', 'resources/fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'trakt_xship'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.xship', 'settings.xml'),
        'default'  : 'api.trakt',
        'data'     : ['api.trakt'],
        'activate' : ''},
    'xship_fanarttv': {
        'name'     : 'Fanart.tv Api [xShip]',
        'saved'    : 'fanarttv_xship',
        'plugin'   : 'plugin.video.xship',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.xship'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.xship', 'resources/icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.xship', 'resources/fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'fanarttv_xship'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.xship', 'settings.xml'),
        'default'  : 'api.fanart.tv',
        'data'     : ['api.fanart.tv'],
        'activate' : ''},
    'xship_opensubtitles': {
        'name'     : 'Opensubtitles.org Account [xShip]',
        'saved'    : 'opensubtitles_xship',
        'plugin'   : 'plugin.video.xship',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.xship'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.xship', 'resources/icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.xship', 'resources/fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'opensubtitles_xship'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.xship', 'settings.xml'),
        'default'  : 'subtitles.os_user',
        'data'     : ['subtitles.os_user', 'subtitles.os_pass'],
        'activate' : ''},

    'trakt': {
        'name'     : 'TRAKT Token',
        'saved'    : 'trakt',
        'plugin'   : 'script.trakt',
        'path'     : os.path.join(CONFIG.ADDONS, 'script.trakt'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'script.trakt', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'script.trakt', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'script.trakt', 'settings.xml'),
        'default'  : 'authorization',
        'data'     : ['authorization','user'],
        'activate' : ''},

    'opensubtitles_org': {
        'name'     : 'OpenSubtitles.org Account',
        'plugin'   : 'service.subtitles.opensubtitles',
        'saved'    : 'opensubtitles_org',
        'path'     : os.path.join(CONFIG.ADDONS, 'service.subtitles.opensubtitles'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'service.subtitles.opensubtitles', 'resources/media/os_logo_512x512.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'service.subtitles.opensubtitles', 'resources/media/os_fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'opensubtitles_org'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'service.subtitles.opensubtitles', 'settings.xml'),
        'default'  : 'OSuser',
        'data'     : ['OSuser', 'OSpass'],
        'activate' : ''},
    'opensubtitles_com': {
        'name'     : 'OpenSubtitles.com Account',
        'plugin'   : 'service.subtitles.opensubtitles-com',
        'saved'    : 'opensubtitles_com',
        'path'     : os.path.join(CONFIG.ADDONS, 'service.subtitles.opensubtitles-com'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'service.subtitles.opensubtitles-com', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'service.subtitles.opensubtitles-com', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'opensubtitles_com'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'service.subtitles.opensubtitles-com', 'settings.xml'),
        'default'  : 'OSuser',
        'data'     : ['OSuser', 'OSpass', 'APIKey'],
        'activate' : ''},

    'youtube': {
        'name'     : 'YouTube API',
        'saved'    : 'youtube',
        'plugin'   : 'plugin.video.youtube',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.youtube'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.youtube', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.youtube', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'youtube'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.youtube', 'settings.xml'),
        'default'  : 'youtube.api.key',
        'data'     : ['youtube.api.enable', 'youtube.api.key', 'youtube.api.id', 'youtube.api.secret'],
        'activate' : ''},
    'youtube_music': {
        'name'     : 'YT Music EXP',
        'saved'    : 'youtube_music',
        'plugin'   : 'plugin.audio.ytmusic.exp',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.audio.ytmusic.exp'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.audio.ytmusic.exp', 'resources/media/icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.audio.ytmusic.exp', 'resources/media/fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'youtube_music'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.audio.ytmusic.exp', 'settings.xml'),
        'default'  : 'youtube.api.id',
        'data'     : ['youtube.api.id', 'youtube.api.secret'],
        'activate' : ''},		
    'youtube_musicbox': {
        'name'     : 'You(T) Musicbox Api',
        'saved'    : 'youtube_musicbox',
        'plugin'   : 'plugin.video.spotitube',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.spotitube'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.spotitube', 'resources/media/icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.spotitube', 'resources/media/fanart.jpg'),
        'file'     : os.path.join(CONFIG.LOGINFOLD, 'youtube_musicbox'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.spotitube', 'settings.xml'),
        'default'  : 'pers_apiKey',
        'data'     : ['pers_apiKey'],
        'activate' : ''}
}

def login_user(who):
    user = None
    if LOGINID[who]:
        if os.path.exists(LOGINID[who]['path']):
            try:
                add = tools.get_addon_by_id(LOGINID[who]['plugin'])
                user = add.getSetting(LOGINID[who]['default'])
            except:
                pass
    return user

def login_it(do, who):
    if not os.path.exists(CONFIG.ADDON_DATA):
        os.makedirs(CONFIG.ADDON_DATA)
    if not os.path.exists(CONFIG.LOGINFOLD):
        os.makedirs(CONFIG.LOGINFOLD)
    if who == 'all':
        for log in ORDER:
            if os.path.exists(LOGINID[log]['path']):
                try:
                    addonid = tools.get_addon_by_id(LOGINID[log]['plugin'])
                    default = LOGINID[log]['default']
                    user = addonid.getSetting(default)
                    
                    update_login(do, log)
                except:
                    pass
            else:
                logging.log('[Login Info] {0}({1}) is not installed'.format(LOGINID[log]['name'], LOGINID[log]['plugin']), level=xbmc.LOGERROR)
        CONFIG.set_setting('loginnextsave', tools.get_date(days=3, formatted=True))
    else:
        if LOGINID[who]:
            if os.path.exists(LOGINID[who]['path']):
                update_login(do, who)
        else:
            logging.log('[Login Info] Invalid Entry: {0}'.format(who), level=xbmc.LOGERROR)

def clear_saved(who, over=False):
    if who == 'all':
        for login in LOGINID:
            clear_saved(login,  True)
    elif LOGINID[who]:
        file = LOGINID[who]['file']
        if os.path.exists(file):
            os.remove(file)
            logging.log_notify('{1}'.format(CONFIG.COLOR1, LOGINID[who]['name']),
                               'Login Information: [COLORred]Entfernt![/COLOR]'.format(CONFIG.COLOR2),
                               2000,
                               LOGINID[who]['icon'])
        CONFIG.set_setting(LOGINID[who]['saved'], '')
    if not over:
        xbmc.executebuiltin('Container.Refresh()')

def update_login(do, who):
    file = LOGINID[who]['file']
    settings = LOGINID[who]['settings']
    data = LOGINID[who]['data']
    addonid = tools.get_addon_by_id(LOGINID[who]['plugin'])
    saved = LOGINID[who]['saved']
    default = LOGINID[who]['default']
    user = addonid.getSetting(default)
    suser = CONFIG.get_setting(saved)
    name = LOGINID[who]['name']
    icon = LOGINID[who]['icon']

    if do == 'update':
        if not user == '':
            try:
                root = ElementTree.Element(saved)
                
                for setting in data:
                    login = ElementTree.SubElement(root, 'login')
                    id = ElementTree.SubElement(login, 'id')
                    id.text = setting
                    value = ElementTree.SubElement(login, 'value')
                    value.text = addonid.getSetting(setting)
                  
                tree = ElementTree.ElementTree(root)
                tree.write(file)
                
                user = addonid.getSetting(default)
                CONFIG.set_setting(saved, user)
                
                logging.log('Login Data Saved for {0}'.format(name), level=xbmc.LOGINFO)
            except Exception as e:
                logging.log("[Login Data] Unable to Update {0} ({1})".format(who, str(e)), level=xbmc.LOGERROR)
        else:
            logging.log('Login Data Not Registered for {0}'.format(name))
    elif do == 'restore':
        if os.path.exists(file):
            tree = ElementTree.parse(file)
            root = tree.getroot()
            
            try:
                for setting in root.findall('login'):
                    id = setting.find('id').text
                    value = setting.find('value').text
                    addonid.setSetting(id, value)
                    
                user = addonid.getSetting(default)
                CONFIG.set_setting(saved, user)
                logging.log('Login Data Restored for {0}'.format(name), level=xbmc.LOGINFO)
            except Exception as e:
                logging.log("[Login Info] Unable to Restore {0} ({1})".format(who, str(e)), level=xbmc.LOGERROR)
        else:
            logging.log('Login Data Not Found for {0}'.format(name))
    elif do == 'clearaddon':
        logging.log('{0} SETTINGS: {1}'.format(name, settings), level=xbmc.LOGDEBUG)
        if os.path.exists(settings):
            try:
                tree = ElementTree.parse(settings)
                root = tree.getroot()
                
                for setting in root.findall('setting'):
                    if setting.attrib['id'] in data:
                        logging.log('Removing Setting: {0}'.format(setting.attrib))
                        root.remove(setting)
                            
                tree.write(settings)
                
                logging.log_notify("{1}".format(CONFIG.COLOR1, name),
                                   'Addon Daten: [COLORred]Entfernt![/COLOR]'.format(CONFIG.COLOR2),
                                   2000,
                                   icon)
            except Exception as e:
                logging.log("[Trakt Data] Unable to Clear Addon {0} ({1})".format(who, str(e)), level=xbmc.LOGERROR)
    xbmc.executebuiltin('Container.Refresh()')

def auto_update(who):
    if who == 'all':
        for log in LOGINID:
            if os.path.exists(LOGINID[log]['path']):
                auto_update(log)
    elif LOGINID[who]:
        if os.path.exists(LOGINID[who]['path']):
            u = login_user(who)
            su = CONFIG.get_setting(LOGINID[who]['saved'])
            n = LOGINID[who]['name']
            if not u or u == '':
                return
            elif su == '':
                login_it('update', who)
            elif not u == su:
                dialog = xbmcgui.Dialog()

                if dialog.yesno(CONFIG.ADDONTITLE,"Willst du die [COLORdeepskyblue]Login Informationen[/COLOR] für [COLORdeepskyblue]{2}[/COLOR] sichern?".format(CONFIG.COLOR2, CONFIG.COLOR1, n)
                                    +'\n'+"Addon: [COLORlime]{0}[/COLOR]".format(u)
                                    +'\n'+"Backup: [COLORred]{0}[/COLOR]".format(su) if not su == '' else 'Backup: [COLORred]Keine[/COLOR]',
                                    yeslabel="[COLORlime]JA[/COLOR]",
                                    nolabel="[COLORred]NEIN[/COLOR]"):
                    login_it('update', who)
            else:
                login_it('update', who)

def import_list(who):
    if who == 'all':
        for log in LOGINID:
            if os.path.exists(LOGINID[log]['file']):
                import_list(log)
    elif LOGINID[who]:
        if os.path.exists(LOGINID[who]['file']):
            file = LOGINID[who]['file']
            addonid = tools.get_addon_by_id(LOGINID[who]['plugin'])
            saved = LOGINID[who]['saved']
            default = LOGINID[who]['default']
            suser = CONFIG.get_setting(saved)
            name = LOGINID[who]['name']
            
            tree = ElementTree.parse(file)
            root = tree.getroot()
            
            for setting in root.findall('login'):
                id = setting.find('id').text
                value = setting.find('value').text
            
                addonid.setSetting(id, value)

            logging.log_notify("{1}".format(CONFIG.COLOR1, name),'Login Daten: [COLORdeepskyblue]Importiert![/COLOR]'.format(CONFIG.COLOR2))

def activate_login(who):
    if LOGINID[who]:
        if os.path.exists(LOGINID[who]['path']):
            act = LOGINID[who]['activate']
            addonid = tools.get_addon_by_id(LOGINID[who]['plugin'])
            if act == '':
                addonid.openSettings()
            else:
                xbmc.executebuiltin(LOGINID[who]['activate'])
        else:
            dialog = xbmcgui.Dialog()

            dialog.ok(CONFIG.ADDONTITLE, '{0} is not currently installed.'.format(LOGINID[who]['name']))
    else:
        xbmc.executebuiltin('Container.Refresh()')
        return

    check = 0
    while not login_user(who) or login_user(who) == "":
        if check == 30:
            break
        check += 1
        time.sleep(10)
    xbmc.executebuiltin('Container.Refresh()')

##############################################################
#                                                            #
#  Copyright (C) 2025 SGKodi / Kodi Unlimited Support Group  #
#                                                            #
##############################################################	